
var socket = io.connect("http://localhost:3000");
        socket.on('connect', function(data){
           console.log("ghgfhgjgjgjlgfjfgfjhgjh,f jhnmfj,ghk,ghjfgjghgfmgh");
        });


       
       alert("OK tady to jede"); 

       
       $("input:submit").click(function(){
                  //alert("OK, zprráva byla poslána");
       })

       socket.on('new message', function(data) {
                  

          if(data) {
              var jmeno = $("#nick").val();
              var num = new Array();
              num.push('3', socket.id, $("#nick").val(), $("#message").val());
              /*
              num[2] = $("#nick").val();
              console.log(num[2]);
              */

              console.log(num);
          }
          $("#chat").append("<li><b>" + socket.id + "</b>" + data.msg + "</li>");
          $("#status").append("<li>" + data.msg + "</li>");
          


       });
     /*var target = document.getElementById( "target" );
 
$( target ).html( "<td>Hello <b>World</b>!</td>" );
*/
       

       socket.on('stat', function(data){
                  $("#status").css("background-color", "green");
                  $("#status").append("<li>" + data+ "</li>");
                  $("#chat").hide();


       });

       socket.on('akce', function(data){
                  //$("#status").append("<img src='http://maturita.albertpatera.cz/dlouhodobka/img/coins.png'>");
                  $("#hide-money").append("<img src='http://findicons.com/files/icons/193/financial/48/green_dollar.png'>");
                  $("#hide-money").fadeIn(350);
                  $("#hide-money").fadeOut(500);
                  
       })

       var $mf = $("#send-message");
       var $ab = $("#action");
       var $lf = $("#login");

       //This is function for display text to chat
       $mf.submit(function(e){
                  e.preventDefault();
                  //console.log("Pressed");
                  socket.emit('new message', $("#message").val());
                  $("#message").val('');

       });

       /*for(var i = 0; i < socket_list.length; i++) { 
    console.log(socket_list[i].id); 
}
*/
       //login area

       socket.on('login', function(data){
       console.log(data);
                  $("#list").append("<li>" + data.users + "</li>");
          $("#list").append("<p style='color:red'>" + data.auth + "</p>");
          
          /*
          var html = '';
          for(var i = 0; i < data.length; i++){
            //console.log(users[i]);
            html += data[i];
            retezec[] = data;
          }

          */

          //$("#list").html(html);

          /*
          var ret = new Array("jkj");
          for(var i = 0; i < data.length; i++) {
            //ret +=data[i].id;
            console.log()
          }

          $("#list").append("<li>" + ret + "</li>");
*/


          
          
          
                  
                  //podmínka, jestli byly přijaty nějaká data
                  if(!data){
                        //$("#chat").fadeIn(3000);
                        $("body").css("background-color", "red");
                        $("#chat").hide();
                        alert("Nebyla zadána zpráva");
                  } else {
                        //$("#chat").hide();
                        //$("body").css("background-color", "#0073f7");
                        $("#chat").fadeIn(1500);
                  }
       });
       //login area - submit data from form 

       $lf.submit(function(e){
            e.preventDefault();
            console.log("Prihlaseni uzivatele " + $("#nick").val() + " bylo uspesne");
            socket.emit('login', $("#nick").val());
            $("#nick").val('');
       });
       
       

       //functon while action button  will be pressed

       

       

       $ab.submit(function(e){
            e.preventDefault();
            console.log("Action button was pressed");
            socket.emit('akce', $("#actionBtn").val());
            $("#status").val('');
       });

       

*/
       

