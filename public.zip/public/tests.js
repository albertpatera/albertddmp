var target = $("#add");
$(target).html("ggjhgjhfgjhghgdfhg");

$("#button").click(function(){
	$(target).append("OKOKOIKOKKKOKKOKKOKOKOKK");
});

var html = 'A';




alert("TEST.JS allready running...");