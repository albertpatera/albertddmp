var $hide = $(".fa fa-chevron-up fa-4");
$(".fa fa-chevron-up fa-4").show();
$("#hide-forms").click(function(){
	//$("fieldset").fadeOut(2000);
  $("fieldset").slideUp(300);
  
  //$("#hide-forms").animate({height: "300px"});
  $("#hide-forms").animate({font-size: "500px"});
  $("#hide-forms").animate({height: "300px"});
  $("fieldset").fadedIn(500);
  $(".fa fa-chevron-up fa-4").hide(300);
	//$("#hide-forms").hide();
  $("#hide-forms").hide(300);
  //$("#hide-forms").show(500);
  $("#hide-forms").html('<i class="fa fa-chevron-right fa-3" aria-hidden="true"></i>');
  
  $("#hide-forms").css("height", "50px");
	alert("ok click");
  
  
  
})

alert("load..");