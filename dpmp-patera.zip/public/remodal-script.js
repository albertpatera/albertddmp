function msg(){
	
	
	
	console.log("testtesttesttesttesttesttest");
	$("#statusbar").mouseover(function(){
		$("body").css("background-color", "green");
		$(".fmsg").html('<a href="#modal">Click to login</a>');
		$(".fmsg").css("display", "block");
		$(".fmsg").css("margin", "0 auto");
	})

	$("body").mouseover(function(){
		console.log("Running ....");
		$("body").append("<div class='remodal' data-remodal-id='modal'>");
		$(".remodal").css("display", "block");
		

		$("body").html("<div class='flogin'></div>");
		$(".flogin").css("background-color", "white");
		$(".flogin").css("border-radius", "6px");
		$(".flogin").css("width", "750px");
		$(".flogin").css("height", "350px");
		$(".flogin").css("display", "block");
		$(".flogin").css("margin", "0 auto");
		$("body").css("opacity", "0.1");

		//$("body").css("background-color", "black");
		$("body").css("opacity", "0.1");
		$(".flogin").css("opacity", "1");
	})

}

//console.log(msg());


function text(text){
	//console.log("ahoj, já jsem text z funce text");
	return alert('Albert patera');

}

alert(text());




    
    
    
    
    
    
