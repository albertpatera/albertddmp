var x = prompt("zadej jméno");
alert("<input type='text' name='username' id='nick'>");