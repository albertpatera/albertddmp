/**
 * Created by Albert on 14.07.2017.
 */
/**
 * Funkce pro načtení všech dostupných vylepšení
 * @param {string} upgrades Název Upgradu
 * @package Bootstrap\App\template\Extension
 * @return Funkce pro vsech nazvu upgradu
 */
