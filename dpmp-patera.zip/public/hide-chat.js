var $hide = $(".fa fa-chevron-up fa-4");
$("#show-form").hide();
$(".fa fa-chevron-up fa-4").show();
$("#hide-forms").click(function(){
	//$("fieldset").fadeOut(2000);
  $("fieldset").slideUp(300);
  $(".fa fa-chevron-down fa-4").hide();
  
  //$("#hide-forms").animate({height: "300px"});
  ///$("#hide-forms").animate({font-size: "500px"});
  $("#hide-forms").animate({height: "300px"});
  
  $(".fa fa-chevron-up fa-4").hide(300);
	//$("#hide-forms").hide();
  $("#hide-forms").hide(300);
  $("#show-form").show();
  $("span").css("height", "35px");
  $("span").css("background-color", "#159753");
  $("span").css("width", "25%");
  //$("#hide-forms").show(500);
  
  
  $("#hide-forms").css("height", "50px");



  if($("fieldset").fadedIn(500)) {
    $("#hide-forms").html("<li>Class</li>");
    $("#hide-forms").html("<i class='fa fa-chevron-down fa-4' aria-hidden='true'></i>")
  } else {
    $("#hide-forms").html("<p style='color:red'>Critical Error !</p>");
  }

	
  
  
  
})


$(".buy").click(function(){
  $("body").css("background-color", "#157aaa");
  console.log(this.dataset);
  console.log("Zakoupeno zbozi" + this.dataset);


})

$(".buy").click(function(){
  console.log(this.dataset);
  alert("zakoupeno zbozi s ID" + this.dataset.id+ "s nazvem" + this.upgrades.nazev);
})



alert("ok, its running...");

/*
  @TODO - dodelat zitra CLICK FCI na zachytavani tlacitka v JQuery 
*/





