# albertddmp

This id First Testing file on my Git Repository

<hr>
<h2>Online game</h2>
<p>
  This is online game powered by SOCKET IO
</p>


<p>
For more information please visit local <b>Wiki</b> on the <a href='https://github.com/albertpatera/albertddmp/wiki/Get-Started'>LINK</a> 
</p>
---
<h3>Contributors</h3>
  <p>
  - <i>Albert Patera <a href='mailto:info@albertpatera.cz'>E-Mail</a> <a href='http://albertpatera.cz'>Website</a></i>
  </p>
